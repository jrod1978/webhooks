# Retell AI Timezone Webhook

This is a simple webhook that returns the current date and time for a specified timezone. It's designed to be called by Retell AI.

## Setup

1. Install dependencies:

